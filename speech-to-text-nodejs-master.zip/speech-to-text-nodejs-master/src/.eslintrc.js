module.exports = {
    extends: '../.eslintrc.js',
    "env": {
        "browser": true,
        "es6": true,
        "jquery": true
    },
    "globals": {
        "BUFFERSIZE": true
    }
};
