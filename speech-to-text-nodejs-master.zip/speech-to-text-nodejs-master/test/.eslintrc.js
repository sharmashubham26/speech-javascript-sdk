module.exports = {
    extends: '../.eslintrc.js',
    "env": {
        "node": true,
        "mocha": true
    }
};
